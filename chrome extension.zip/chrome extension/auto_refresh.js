// 1. Create variables to store your HTML elements.
const divEl = document.getElementById ('data-table') ;
// 2. Create a function that responds to an event
function onChange () {
// 4. Change the html element's style in the function you created.
//   divEl.style.backgroundColor = 'red';
// divEl.innerHTML = '';
reportJS()
}
// 3. Attach that function to an event listener
divEl.addEventListener('mousemove', onChange);