// background.js

let websiteData = {};

chrome.runtime.onMessage.addListener(function (message) {
  if (message.command === "trackWebsite") {
    trackWebsite(message.url, message.source);
    chrome.runtime.sendMessage({ message: "refresh" });
    reportJS()
  }
});

chrome.runtime.onMessage.addListener(function (message) {
  if (message.command === "clearWebsiteData") {
    websiteData = {};
    chrome.storage.local.set({ websiteData });
    reportJS()
  }
});

function trackWebsite(url, source) {
  const currentTime = Date.now();
  if (!websiteData[url]) {
    websiteData[url] = {
      totalTime: 0,
      lastVisitTime: currentTime,
      page_source: source,
    };
  } else {
    const elapsedTime = currentTime - websiteData[url].lastVisitTime;
    websiteData[url].totalTime += elapsedTime;
    websiteData[url].lastVisitTime = currentTime;
  }

  // Save the updated websiteData to Chrome storage.
  chrome.storage.local.set({ websiteData });

  console.log(websiteData); // Print the websiteData object to the console.
}

// Load the stored websiteData from Chrome storage on startup.
chrome.storage.local.get("websiteData", function (data) {
  websiteData = data.websiteData || {};
});

// Send the websiteData to the popup whenever it is requested.
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.command === "getWebsiteData") {
    sendResponse({ websiteData });
  }
  return true;
});
