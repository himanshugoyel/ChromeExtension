const clearDataButton = document.getElementById("clear-data");
clearDataButton.addEventListener("click", function () {
  chrome.runtime.sendMessage({ command: "clearWebsiteData" });
});