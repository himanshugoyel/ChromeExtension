// content.js

// Send a message to the background script when a new page is loaded.
chrome.runtime.sendMessage({ command: "trackWebsite", url: window.location.href, source: document.documentElement.outerHTML });