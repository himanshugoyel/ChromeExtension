// report.js

// Fetch websiteData from the background script and update the table in report.html.

chrome.runtime.sendMessage({ command: "getWebsiteData" }, function (response) {
    const websiteData = response.websiteData;
    const table = document.querySelector("table");
    const addedTitles = new Set(); // Keep track of titles that have already been added
    // const numRowsBefore = table.rows.length;
    // Sort the websiteData object by lastVisitTime in descending order
    const sortedWebsiteData = Object.entries(websiteData)
        .sort(([, a], [, b]) => b.lastVisitTime - a.lastVisitTime)
        .reduce((r, [k, v]) => ({ ...r, [k]: v }), {});
        
    for (const url in sortedWebsiteData) {
        const tr = document.createElement("tr");
        const tdWebsite = document.createElement("td");
        const tdTitle = document.createElement("td");
        const tdAuthor = document.createElement("td");
        const tdTime = document.createElement("td");
        const tdSource = document.createElement("td");

        const parser = new DOMParser();
        const doc = parser.parseFromString(sortedWebsiteData[url].page_source, "text/html")

        const metaTag = doc.querySelector('meta[name="parsely-author"]');
        
        if (metaTag) {
            const content = metaTag.getAttribute("content");
            tdAuthor.textContent = content;
        }
         else {
            tdAuthor.textContent = "N/A";
        }

        tdTime.textContent = new Date(sortedWebsiteData[url].lastVisitTime).toLocaleString();
        tdWebsite.textContent = url;
        tdSource.textContent = sortedWebsiteData[url].page_source;
        
        const titleLink = document.createElement("a");
        titleLink.setAttribute("href", url);
        titleLink.textContent = doc.title;

        tdTitle.appendChild(titleLink);
        
        // Skip adding a row if the title has already been added
        const title = doc.title;
        if (addedTitles.has(title)) {
            continue;
        }
        addedTitles.add(title);
        tr.appendChild(tdTitle);
        tr.appendChild(tdAuthor);
        tr.appendChild(tdTime);
        tr.appendChild(tdWebsite);
        tr.appendChild(tdSource);
        table.appendChild(tr);
        // const numRowsAfter = table.rows.length
        
        // // if before table length and fater table length different run location reload
        // if (numRowsBefore !== numRowsAfter) {
        //     location.reload();
        // }
    }
  });

const clearDataButton = document.getElementById("clear-data");
clearDataButton.addEventListener("click", function () {
  chrome.runtime.sendMessage({ command: "clearWebsiteData" });
});
const hideSourceColumnStyle = document.createElement("style");
hideSourceColumnStyle.textContent = `
  #data-table td:nth-child(5),
  #data-table th:nth-child(5) {
    display: none;
  }
`;
document.head.appendChild(hideSourceColumnStyle);

// chrome.runtime.onMessage.addListener(function (message) {
//   if (message.command === "refresh") {
//     // refreshTable();
//     console.log("Refreshing table");
//   }
// });
