// search.js

// Function to handle search functionality
function handleSearch() {
    const searchInput = document.getElementById("searchInput");
    const query = searchInput.value.trim().toLowerCase();
    filterRows(query);
  }
  
  // Function to filter rows based on the search query
  function filterRows(query) {
    const table = document.getElementById("data-table");
    const rows = table.getElementsByTagName("tr");
  
    for (let i = 1; i < rows.length; i++) { // Start from 1 to skip the header row
      const row = rows[i];
      const rowData = row.textContent.trim().toLowerCase();
  
      if (rowData.includes(query)) {
        row.style.display = "";
      } else {
        row.style.display = "none";
      }
    }
  }
  
  // Attach event listener to search input
  const searchInput = document.getElementById("searchInput");
  searchInput.addEventListener("input", handleSearch);
  